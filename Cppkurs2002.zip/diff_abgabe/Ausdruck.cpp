#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "ausdruck.h"

Konstante::Konstante(double zahl)
{
	wert=zahl;
}

double Konstante::auswerten(double)
{
	return wert;
}

Ausdruck *Konstante::ableiten()
{
	Ausdruck *temp=new Konstante(0.0);
	return temp;

}

char *Konstante::to_chr()
{
	char *str=new char[20];
	sprintf(str,"%E",wert);
	return str;

}


////////////////////////////////////////////////
//  Methoden Klasse Variable
////////////////////////////////////////////////



Ausdruck *Variable::ableiten()
{
	return new Konstante(1.0);
}

double Variable::auswerten(double x)
{
	return x;
}

char *Variable::to_chr()
{
	char *name = new char[2];
	name[0] ='x';
	name[1] ='\0';
	return name;
}

////////////////////////////////////////////////
//  Methoden Klasse Add
////////////////////////////////////////////////


Ausdruck *Add::ableiten()
{
	Ausdruck *left=links->ableiten();
	Ausdruck *right=rechts->ableiten();
	if(left->is_zero()) 
	{
		delete left;
		return right;
	}

	if(right->is_zero()) 
	{
		delete right;
		return left;
	}

	Ausdruck *temp=new Add(left,right);

	return temp;

};

double Add::auswerten(double zahl)
{
	return links->auswerten(zahl)+rechts->auswerten(zahl);
}

char *Add::to_chr()
{
	char *chr_links=links->to_chr();
	char *chr_rechts=rechts->to_chr();
	int len = strlen(chr_links)+strlen(chr_rechts)+5;
	char *chr_exp = new char [len+1];
	chr_exp[0]='(';
	strcpy(&chr_exp[1],chr_links);
	strcat(chr_exp,")+(");
	strcat(chr_exp,chr_rechts);
	strcat(chr_exp,")");
		

	// gegen Speicherluecken
	delete chr_links;
	delete chr_rechts;

	return chr_exp;
}

Ausdruck *Add::kopieren()
{
	Ausdruck *a=links->kopieren();
	Ausdruck *b=rechts->kopieren();
	Ausdruck *temp=new Add(a,b);
	return temp;
}


////////////////////////////////////////////////
//  Methoden Klasse Sub
////////////////////////////////////////////////


Ausdruck *Sub::ableiten()
{
	Ausdruck *left=links->ableiten();
	Ausdruck *right=rechts->ableiten();


	if(right->is_zero()) 
	{
		delete right;
		return left;
	}

	Ausdruck *temp=new Sub(left,right);

	return temp;

};


double Sub::auswerten(double zahl)
{
	return links->auswerten(zahl)-rechts->auswerten(zahl);
}

char *Sub::to_chr()
{
	char *chr_links=links->to_chr();
	char *chr_rechts=rechts->to_chr();
	int len = strlen(chr_links)+strlen(chr_rechts)+5;
	char *chr_exp = new char [len+1];
	chr_exp[0]='(';
	strcpy(&chr_exp[1],chr_links);
	strcat(chr_exp,")-(");
	strcat(chr_exp,chr_rechts);
	strcat(chr_exp,")");

	// gegen Speicherluecken
	delete chr_links;
	delete chr_rechts;
	
	return chr_exp;
}

Ausdruck *Sub::kopieren()
{
	Ausdruck *a=links->kopieren();
	Ausdruck *b=rechts->kopieren();
	Ausdruck *temp=new Sub(a,b);
	return temp;
}





////////////////////////////////////////////////
//  Methoden Klasse Mul
////////////////////////////////////////////////


Ausdruck *Mul::ableiten()
///
/// Bildet die Ableitung nach der Produktregel
/// (u*v)' = u' * v + u * v'
///
{
	Ausdruck *dleft=links->ableiten();
	Ausdruck *dright=rechts->ableiten();

	if(dleft->is_zero() && dright->is_zero()) 
	{
		delete dleft;dleft=0;
		delete dright;dright=0;
		return new Konstante(0.0);
	}
		
	Ausdruck *left=0;
	Ausdruck *right=0;
	
	if(!dright->is_zero()) left=links->kopieren();
	if(!dleft->is_zero()) right=rechts->kopieren();


	if(dleft->is_zero()) 
	{
		delete dleft;dleft=0;
	
		if(dright->is_one())
		{
			delete dright;
			return left;
		}
	   Ausdruck *temp=new Mul(left,dright);

		return temp;
	}

	if(dright->is_zero()) 
	{
		delete dright;dright=0;

		if(dleft->is_one())
		{
			delete dleft;
			return right;
		}

		Ausdruck *temp=new Mul(dleft,right);
		return temp;
	}



	Ausdruck *neu_links=new Mul(dleft,right);
	Ausdruck *neu_rechts=new Mul(left,dright);
	Ausdruck *temp=new Add(neu_links,neu_rechts);

	return temp;

};


double Mul::auswerten(double zahl)
{
	return links->auswerten(zahl)*rechts->auswerten(zahl);
}

/*
string Mul::to_string()
{
	string s;
	s="(";
	s+=links->to_string;
	*/


char *Mul::to_chr()
{
	char *chr_links=(links?links->to_chr():"Null");
	char *chr_rechts=(rechts?rechts->to_chr():"Null");
	int len = strlen(chr_links)+strlen(chr_rechts)+5;
	char *chr_exp = new char [len+1];
	chr_exp[0]='(';
	strcpy(&chr_exp[1],chr_links);
	strcat(chr_exp,")*(");
	strcat(chr_exp,chr_rechts);
	strcat(chr_exp,")");

	// gegen Speicherluecken
	delete chr_links;
	delete chr_rechts;

	return chr_exp;
}


Ausdruck *Mul::kopieren()
{
	Ausdruck *a=links->kopieren();
	Ausdruck *b=rechts->kopieren();
	Ausdruck *temp=new Mul(a,b);
	return temp;
}




////////////////////////////////////////////////
//  Methoden Klasse Div
////////////////////////////////////////////////


Ausdruck *Div::ableiten()
////////////////////////////////////////////
// Ableitung nach der Formel:
//  (u/v)' = (u'*v -u*v' )/ v^2
/////////////////////////////////////////
{
	Ausdruck *dleft=links->ableiten();    // u'
	Ausdruck *dright=rechts->ableiten();  // v'

	if(dleft->is_zero() && dright->is_zero()) 
	{
		delete dleft;dleft=0;
		delete dright;dright=0;
		return new Konstante(0.0);
	}

		
	Ausdruck *left=0;
	Ausdruck *right=0;
	
	if(!dright->is_zero()) left=links->kopieren();
	/*if(!dleft->is_zero())*/ right=rechts->kopieren();


	if(dleft->is_zero()) 
	{
		/*
		delete dleft;dleft=0;
	
		if(dright->is_one())
		{
			delete dright;
			return left;
		}
	   Ausdruck *temp=new Div(left,dright);

		return temp;
		*/
	}

	if(dright->is_zero()) 
		//Wenn rechter Ausdruck konstant ist und damit die Ableitung 0
		// So gilt (u/v)'= u'/v (wenn v'=0)
	{
		
		delete dright;dright=0;

		Ausdruck *temp=new Div(dleft,right);
		return temp;
		
	}



	Ausdruck *neu_links=new Mul(dleft,right);
	Ausdruck *neu_rechts=new Mul(left,dright);
	Ausdruck *temp=new Sub(neu_links,neu_rechts);
	Ausdruck *abl =new Div(temp,new Sqr(rechts->kopieren()));

	return abl;

};


double Div::auswerten(double zahl)
{
	return links->auswerten(zahl)/rechts->auswerten(zahl);
}

char *Div::to_chr()
{
	char *chr_links=links->to_chr();
	char *chr_rechts=rechts->to_chr();
	int len = strlen(chr_links)+strlen(chr_rechts)+5;
	char *chr_exp = new char [len+1];
	chr_exp[0]='(';
	strcpy(&chr_exp[1],chr_links);
	strcat(chr_exp,")/(");
	strcat(chr_exp,chr_rechts);
	strcat(chr_exp,")");
	
	// gegen Speicherluecken
	delete chr_links;
	delete chr_rechts;

	return chr_exp;
}


Ausdruck *Div::kopieren()
{
	Ausdruck *a=links->kopieren();
	Ausdruck *b=rechts->kopieren();
	Ausdruck *temp=new Div(a,b);
	return temp;
}


////////////////////////////////////////////////
//  Methoden Klasse Pow
////////////////////////////////////////////////


Ausdruck *Pow::ableiten()
{

/***********************************

  Fuer die Ableitung gilt:
  (a^b)' = (b*ln(a))' * (a^b)

************************************/

	Ausdruck *lna=new Log(links->kopieren());
	Ausdruck *inner= new Mul(rechts->kopieren(),lna); //(b*ln(a))
	Ausdruck *inner_abl=inner->ableiten();            //(b*ln(a))'
	if(inner_abl->is_zero())
	{ //in diesem Fall ist das ganze Ergebniss 0
		delete inner;inner =0;
		delete inner_abl;inner_abl=0;
		return new Konstante(0.0);
	}

	Ausdruck *abl=new Mul(inner_abl,this->kopieren());
	delete inner;inner =0;
	return abl;


//	Ausdruck *dleft=links->ableiten();
//	Ausdruck *dright=rechts->ableiten();

//	if(dleft->is_zero() && dright->is_zero()) return new Konstante(0.0);


/*	
	Ausdruck *left=0;
	Ausdruck *right=0;
	
	if(!dright->is_zero()) left=links->kopieren();
	if(!dleft->is_zero()) right=rechts->kopieren();


	if(dleft->is_zero()) 
	{
		delete dleft;dleft=0;
	
		if(dright->is_one())
		{
			delete dright;
			return left;
		}
	   Ausdruck *temp=new Pow(left,dright);

		return temp;
	}

	if(dright->is_zero()) 
	{
		delete dright;dright=0;

		if(dleft->is_one())
		{
			delete dleft;
			return right;
		}

		Ausdruck *temp=new Pow(dleft,right);
		return temp;
	}



	Ausdruck *neu_links=new Pow(dleft,right);
	Ausdruck *neu_rechts=new Pow(left,dright);
	Ausdruck *temp=new Add(neu_links,neu_rechts);

	return temp;
*/
};


double Pow::auswerten(double zahl)
{
	return pow(links->auswerten(zahl),rechts->auswerten(zahl));
}

char *Pow::to_chr()
{
	char *chr_links=links->to_chr();
	char *chr_rechts=rechts->to_chr();
	int len = strlen(chr_links)+strlen(chr_rechts)+5;
	char *chr_exp = new char [len+1];
	strcpy(chr_exp,"pow(");
	strcat(chr_exp,chr_links);
	strcat(chr_exp,",");
	strcat(chr_exp,chr_rechts);
	strcat(chr_exp,")");

	// gegen Speicherluecken
	delete chr_links;
	delete chr_rechts;
	
	return chr_exp;
}


Ausdruck *Pow::kopieren()
{
	Ausdruck *a=links->kopieren();
	Ausdruck *b=rechts->kopieren();
	Ausdruck *temp=new Pow(a,b);
	return temp;
}

//////////////////////////////////////////////
///  Methoden Klasse Funktion
//////////////////////////////////////////////

Ausdruck *Funktion::ableiten()
// Ableitung nach der Kettenregel

{
	Ausdruck *innere_abl=parameter->ableiten();
    Ausdruck *aeussere_abl=aussen_ableitung();

	return new Mul(innere_abl,aeussere_abl);

}

//////////////////////////////////////////////
///  Methoden Klasse Exp
//////////////////////////////////////////////


Ausdruck *Exp::aussen_ableitung()

{
	Ausdruck *para=parameter->kopieren();
	Ausdruck *erg=new Exp(para);
	return erg;


}

double Exp::auswerten(double zahl)
{
	return exp(parameter->auswerten(zahl));
}

char *Exp::to_chr()
{
	char *chr_para=parameter->to_chr();

	int len = strlen(chr_para)+5;
	char *chr_exp = new char [len+1];
	strcpy(chr_exp,"exp(");
	strcat(chr_exp,chr_para);
	strcat(chr_exp,")");

	// gegen Speicherluecken
	delete chr_para;
	
	return chr_exp;
}

Ausdruck *Exp::kopieren()
{
	Ausdruck *a=parameter->kopieren();
	Ausdruck *temp=new Exp(a);
	return temp;
}


//////////////////////////////////////////////
///  Methoden Klasse Log
//////////////////////////////////////////////


Ausdruck *Log::ableiten()

{
	Ausdruck *innere_abl=parameter->ableiten();
	if(innere_abl->is_zero())
	{
		delete innere_abl;
		return new Konstante(0.0);
	}
	Ausdruck *para=parameter->kopieren();
	Ausdruck *erg=new Div(innere_abl,para);
	return erg;


}

double Log::auswerten(double zahl)
{
	return log(parameter->auswerten(zahl));
}

char *Log::to_chr()
{
	char *chr_para=parameter->to_chr();

	int len = strlen(chr_para)+5;
	char *chr_Log = new char [len+1];
	strcpy(chr_Log,"Log(");
	strcat(chr_Log,chr_para);
	strcat(chr_Log,")");

	delete chr_para;
	
	return chr_Log;
}

Ausdruck *Log::kopieren()
{
	Ausdruck *a=parameter->kopieren();
	Ausdruck *temp=new Log(a);
	return temp;
}

//////////////////////////////////////////////
///  Methoden Klasse Sqr (Quadrat bilden)
//////////////////////////////////////////////


Ausdruck *Sqr::aussen_ableitung()

{
	// (sqr(x))' = 2 * x 
	Ausdruck *para=parameter->kopieren();
	Ausdruck *erg=new Mul(new Konstante(2.0),para);
	return erg;


}

double Sqr::auswerten(double zahl)
{
	double x=parameter->auswerten(zahl);
	return x*x;
}

char *Sqr::to_chr()
{
	char *chr_para=parameter->to_chr();

	int len = strlen(chr_para)+5;
	char *chr_Sqr = new char [len+1];
	strcpy(chr_Sqr,"Sqr(");
	strcat(chr_Sqr,chr_para);
	strcat(chr_Sqr,")");
	
		delete chr_para;

	return chr_Sqr;
}

Ausdruck *Sqr::kopieren()
{
	Ausdruck *a=parameter->kopieren();
	Ausdruck *temp=new Sqr(a);
	return temp;
}

