#include <iostream>
using namespace std;

#include "ausdruck.h"
#include "stack_ausdruck.h"
#include "rechner.h"


#ifdef ANSI_SYS

void pos(int x,int y)
{
	printf("\33[%d;%dH",x,y);
}

void clearscreen()
{
	printf("\33[2J");
}
#endif

int main()
{
	Stack stack;

		Rechner meinrechner;
	char buffer[80];
	double zahl;
	bool err_eingabe=false; // Es wurde unbekanter Befehl eingegeben
	bool neuer_bildschirm = true;//true falls Stack ausgegeben werden soll
	do {

#ifdef ANSI_SYS
		if(neuer_bildschirm){
		clearscreen();
		pos(0,0);
		}
#endif
		if(neuer_bildschirm)
			meinrechner.showstack(5);
		else neuer_bildschirm=true;

#ifdef ANSI_SYS
		cout << endl;
		cout << endl;

		if(err_eingabe)
		{
	//		pos(8,0);
			cout << endl;
			cout << endl;
			cout <<"unbekanter Befehl" << endl;
			cout << "Fuer Hilfe '?' oder 'help' eingeben" <<endl;
			err_eingabe= false;
			pos(10,0);
		}
		else
	//		pos(10,0);


#endif

		
		cout << ">";
		cin >> buffer;
		zahl=atof(buffer);

		if (zahl)  meinrechner.put(zahl);
		else
		if(!strcmp(buffer,"0")) meinrechner.put(0.0);
		else if (!strcmp(buffer,"+"))
			meinrechner.plus();
		else if (!strcmp(buffer,"-"))
			meinrechner.minus();
		else if (!strcmp(buffer,"*"))
			meinrechner.mal();
		else if (!strcmp(buffer,"/"))
			meinrechner.geteilt();
		else if (!strcmp(buffer,"pow"))
			meinrechner.hoch();
		else if (!strcmp(buffer,"^"))
			meinrechner.hoch();
		else if (!strcmp(buffer,"x"))
			meinrechner.put('x');
		else if (!strcmp(buffer,"eval"))
			meinrechner.auswerten();
		else if (!strcmp(buffer,"diff"))
			meinrechner.ableiten();

		
		else if (!strcmp(buffer,"exp"))
			meinrechner.exp();
		else if (!strcmp(buffer,"log"))
			meinrechner.log();
		else if (!strcmp(buffer,"sqr"))
			meinrechner.sqr();

		else if (!strcmp(buffer,"del"))
			meinrechner.del();
		else if (!strcmp(buffer,"clear"))
			meinrechner.clear();
		else if (!strcmp(buffer,"dup"))
			meinrechner.duplicate();


		else if(!strcmp(buffer,"xrange"))
			meinrechner.xrange();
		else if(!strcmp(buffer,"plot"))
		{
			neuer_bildschirm = false;
			meinrechner.plot();
		}
		
		else if(!strcmp(buffer,"helpfunc"))
		{
			neuer_bildschirm = false;
			meinrechner.helpfunc();
		}
		else if(!strcmp(buffer,"help"))
		{
			neuer_bildschirm = false;
			meinrechner.help();
		}
		else if(!strcmp(buffer,"?"))
		{
			neuer_bildschirm = false;
			meinrechner.help();
		}
		else if (!strcmp(buffer,"quit"))
			break;

		else
		{
			err_eingabe=true;
			cout <<"unbekanter Befehl" << endl;
			cout << "Fuer Hilfe '?' oder 'help' eingeben" <<endl;
		}

			




//		cout << strlen(buffer)<<":"<<buffer;
	}while(true);

	return 0;

	
}