//#include <iostream>
//using namespace std;
#include "ausdruck.h"

#ifndef STACK_AUSDRUCK_H
#define STACK_AUSDRUCK_H


const int STACK_SIZE = 50;
class Stack{

private:
	Ausdruck *data[STACK_SIZE];
	int stackpointer;

public:
	Stack():stackpointer(-1){};

	void push(Ausdruck *i){
		data[++stackpointer]=i;
	}

	Ausdruck *pop(){
		if(leer()) return 0;else return data[stackpointer--];
	}

	bool leer(){
		return stackpointer == -1;
	}

};


#endif