#ifndef RECHNER_H
#define RECHNER_H

#include "ausdruck.h"
#include "stack_ausdruck.h"


#define ANSI_SYS
// ANSI_SYS wird gesetzt wenn die Escapesequenzen des
// Treibers ansi.sys fuer die ausgabe benutzt werden sollen



// Die konstanten werden zum plotten der Funktion gebracht
const int FENSTER_BREITE=20;
const int FENSTER_HOEHE=15;


class Rechner{

	Stack stack;
	double x_von,x_bis;

public:

	Rechner(){x_von=0;x_bis=1;}

//////////////////////////////
// Rechenoperationen      ///
/////////////////////////////
	void plus();
	void minus();
	void mal();
	void geteilt();
	void hoch();

	void auswerten(double);
	void auswerten();
	void ableiten();

////////////////////////////
//  plotten              //
////////////////////////////
	void xrange();
	void plot();

////////////////////////////
//  Funktionen            //
////////////////////////////
	
	void exp();
	void log();
	void sqr();

////////////////////////////
// Stackoperationen      ///
////////////////////////////

	
	void put(double zahl){stack.push(new Konstante(zahl));}
	void put(char x){stack.push(new Variable );}
	void del();
	void duplicate();
	void clear();

	void showstack(int i);

////////////////////////////
// Hilfe                 ///
////////////////////////////

	void help();
	void helpfunc();

};

#endif