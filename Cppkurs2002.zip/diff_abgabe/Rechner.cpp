#include <iostream>
using namespace std;

#include "rechner.h"

#ifdef ANSI_SYS
	void clearscreen();
#endif


void Rechner::plus()
{
	//Addiert die beiden obersten Ausdruecke vom Stack
	 Ausdruck *a=stack.pop();
				      Ausdruck *b=stack.pop();
					  if(a && b) {  // kein Stackunderflow
						           Ausdruck *c=new Add(b,a);
								   stack.push(c);
					  }

			//wenn wenniger als zwei Ausdruecke auf dem Stack lagen,
		    //wird die Ursprungssituation des Stacks wiederhergestellt
					  else if (a) stack.push(a);
					 

}
void Rechner::minus()
{
	//Subtrahiert die beiden obersten Ausdruecke vom Stack
	//(allerdings nur falls genuegend vorhanden)
	 Ausdruck *a=stack.pop();
				      Ausdruck *b=stack.pop();
					  if(a && b) {
						           Ausdruck *c=new Sub(b,a);
								   stack.push(c);
					  }
					  else if (a) stack.push(a);
					 

}

void Rechner::mal()
{
	//Multipliziert die beiden obersten Ausdruecke vom Stack
	//(allerdings nur falls genuegend vorhanden)

	 Ausdruck *a=stack.pop();
				      Ausdruck *b=stack.pop();
					  if(a && b) {
						           Ausdruck *c=new Mul(b,a);
								   stack.push(c);
					  }
					  else if (a) stack.push(a);
					 

}

void Rechner::geteilt()
{
	//Dividiert die beiden obersten Ausdruecke vom Stack
	//(allerdings nur falls genuegend vorhanden)

	Ausdruck *a=stack.pop();
				      Ausdruck *b=stack.pop();
					  if(a && b) {
						           Ausdruck *c=new Div(b,a);
								   stack.push(c);
					  }
					  else if (a) stack.push(a);
					 

}

void Rechner::hoch()
{
	//Potenziert die beiden obersten Ausdruecke vom Stack
	//(allerdings nur falls genuegend vorhanden)

	 Ausdruck *a=stack.pop();
				      Ausdruck *b=stack.pop();
					  if(a && b) {
						           Ausdruck *c=new Pow(b,a);

								   stack.push(c);
					  }
					  else if (a) stack.push(a);
					 

}


////////////////////////////////////////////////////////
// Hier sind die Implementierungen fuer die Einzelnen
// Aufrufe der mathematischen Funktionen
// 
//////////////////////////////////////////////////////

void Rechner::exp()
{
	Ausdruck *a=stack.pop();
	if (a) // Wenn Stack nicht leer war
	{
		Ausdruck *tmp=new Exp(a);
		stack.push(tmp);
	}
}
void Rechner::log()
{
	Ausdruck *a=stack.pop();
	if (a)// Wenn Stack nicht leer war
	{
		Ausdruck *tmp=new Log(a);
		stack.push(tmp);
	}
}
void Rechner::sqr()
{
	Ausdruck *a=stack.pop();
	if (a)// Wenn Stack nicht leer war
	{
		Ausdruck *tmp=new Sqr(a);
		stack.push(tmp);
	}
}





void Rechner::ableiten()
{
 Ausdruck *a=stack.pop();
				if (a){
					Ausdruck *b=a->ableiten();
					stack.push(b);
					delete a; // sonst speicherluecke
				}
}


void Rechner::auswerten(double wert)
{
	Ausdruck *a=stack.pop();
	if(a)
	{
		put(a->auswerten(wert));
		delete a;
	}
}


void Rechner::auswerten()
{
    Ausdruck *wert=stack.pop();
	if(wert && wert->is_konstante())
	{
    	Ausdruck *a=stack.pop();
		if(a)
		{
			put(a->auswerten(wert->auswerten(0.0)));
			delete a;a=0;
			delete wert;wert=0;
		}
		else stack.push(wert);
	}else if (wert) put(wert->auswerten(0.0));

}

	
//////////////////////////////////////////////////
// showstack listet die ersten i Elemente des Stacks 
// in Ungekehrter Reihenfolge auf,
// bzw. alle , wenn i=0;
//////////////////////////////////////////////////
void Rechner::showstack(int i)

{
	Ausdruck *a=stack.pop();
	i--;
	if(a && i) showstack(i);
	if(a) cout << a->to_chr() << endl;
	stack.push(a);

}

////////////////////////////////////////////////
// Dupliziert oberstes Element auf dem Stack
// (tiefe Kopie)
///////////////////////////////////////////////
void Rechner::duplicate()
{
	Ausdruck *a=stack.pop();
	if(a){//Stack nicht leer
		stack.push(a->kopieren());//Flache Kopie auf dem Stack koennte 
		                          // fatale folgen haben
		stack.push(a);
	}
}

void Rechner::del()
{
	Ausdruck *a=stack.pop();
	if (a) delete a;
}


void Rechner::clear()
// Loescht den Stack

{
	Ausdruck *a;
	while(a=stack.pop())
		delete a;
}


void Rechner::help()

{
	cout <<"Dies ist ein UPN-Rechner " <<endl; 
	cout <<"Es gibt folgene Kommandos: " <<endl;
	cout <<" <Zahl> \t\t Pack die eingegebene Zahl auf den Stack" << endl;
	cout <<"x  \t\t\t Pack Variable auf den Stack "<<endl;
	cout <<"[+|-|*|/] \t\t fuehrt die Operation auf beiden oben auf den stack"<<endl;
	cout <<"\t\t\t liegenden Ausdruecken aus" << endl;
	cout <<"[^|pow] \t\t  Bildet Potenz" << endl;
	cout  <<"<Ausdruck> <Zahl>  eval  Wertet <Ausdruck> an der Stelle <Zahl> aus"<< endl;
	cout <<"<Ausdruck> diff   Bildet Ableitung von <Ausdruck>" << endl;
	cout << "<zahl> <zahl> xrange\t Setzt den Bereich der X-werte zum Plotten"<<endl;
	cout <<"<Ausdruck> plot \t Plotted den Graph von <Ausdruck>"<< endl; 
	cout << " dup \t\t\t  Kopiert oberstes Stackelement  "<< endl;
	cout << " del \t\t\t  Loescht oberstes Stackelement  "<< endl;
	cout << " clear \t\t\t  Loescht den Stack  "<< endl;
	cout <<" quit \t\t\t Beendet das Programm " << endl;
	cout <<" help \t\t\t Zeigt diese Seite an" << endl;
	cout <<" helpfunc \t\t Zeigt die mathematischen Funktionen an" << endl;



}

void Rechner::helpfunc()
{
	cout << "<zahl>  exp  \t\t\t Exponetialfunktion" << endl;
	cout << "<zahl>  log  \t\t\t nat. Logarithmus" << endl;
	cout << "<zahl>  sqr  \t\t\t Quadrat der Zahl" << endl;

}
void Rechner::xrange()
{
	Ausdruck *a=stack.pop();
	Ausdruck *b=stack.pop();
	if(a && b) 
	{
		double von=	a->auswerten(0.0);
		double bis= b->auswerten(0.0);


		// Es soll gelten: x_von <= x_bis
		if(von<bis)
		{
			x_von=von;
			x_bis=bis;
		}
		else
		{
			x_von=bis;
			x_bis=von;
		}

	}
	 else if (a) stack.push(a);
}




/////////////////////////////////////////////////////////
// Zeichnet den Graph der Funktion auf den Bildschirm
//////////////////////////////////////////////////////

void Rechner::plot()

{
	double y_werte[FENSTER_BREITE];
	Ausdruck *a=stack.pop();
	if(a)
	{
		double schrittweite=(x_bis-x_von)/(FENSTER_BREITE-1);
		for(int i=0;i<FENSTER_BREITE;i++)
		{
			y_werte[i]=a->auswerten(x_von+schrittweite*i);
		}

		double ymin,ymax;
		ymin=ymax=y_werte[0];


		//Ermittle groesten und keinsten Funktionswert
		//damit nacher alle Werte in das Fenster passen
		for(i=1;i<FENSTER_BREITE;i++)
		{
			if (ymin>y_werte[i]) ymin=y_werte[i];
			if (ymax<y_werte[i]) ymax=y_werte[i];
		}



		//Loeschen des Arrays fuer die Ausgabe
		char ausgabe[FENSTER_HOEHE][FENSTER_BREITE+1];
		for(i=0;i<FENSTER_HOEHE;i++)
		{
			for(int j=0;j<FENSTER_BREITE;j++)
				ausgabe[i][j]=' ';
			ausgabe[i][FENSTER_BREITE]='\0';
		}


		//Setzen der Funktionswerte in Graphen
		for(i=0;i<FENSTER_BREITE;i++)
		{
			//j wird ensprechend der Funktionswerte skaliert
			//sodass der Graph die gesammte FENSTER_HOEHE Ausfuellt
			int j=(int)(((y_werte[i]-ymin)/(ymax-ymin))*(FENSTER_HOEHE-1));
			ausgabe[j][i]='*';
		}

		


#ifdef ANSI_SYS
		clearscreen();
#endif
	
		//Ausgabe des Graphen auf die Konsole
		for(i=FENSTER_HOEHE-1;i>=0;i--)
		{ 
			for(int j=0;j<FENSTER_BREITE;j++)
				cout << ausgabe[i][j];
			cout << endl;
		}
	
		//Die Bereiche, aus dem die Werte sind ,
		// d.h. Definitionsbereich (xrange) und Wertebereich (yrange)
		// werden unter den Graphen geschrieben, da ich zu faul bin
		// 
		cout <<"xrange:"<<x_von<<":"<<x_bis<<"       ";
		cout <<"yrange:"<<ymin<<":" <<ymax<< endl;
			





	}
}