#ifndef AUSDRUCK_H
#define AUSDRUCK_H


class Ausdruck{

public:
	virtual Ausdruck *ableiten()=0;
	virtual double auswerten(double)=0;
	virtual char * to_chr()=0;
	Ausdruck(){};
	virtual ~Ausdruck(){};

	virtual Ausdruck *kopieren()=0;

	virtual bool is_konstante() { return false;}
	virtual bool is_zero() { return false;}
	virtual bool is_one() { return false;}

};

class Konstante:public Ausdruck{
	double wert;

public:
	Konstante(double zahl);
	Ausdruck *ableiten();
	double auswerten(double);
	char * to_chr();
	~Konstante(){};
	Ausdruck *kopieren() {return new Konstante(wert);}

	virtual bool is_konstante() { return true;}
	virtual bool is_zero() { return wert==0.0;}
	virtual bool is_one() { return wert==1.0;}

};

class Variable:public Ausdruck{

public:
	Variable(){};
	Ausdruck *ableiten();
	double auswerten(double);
	char * to_chr();
	Ausdruck *kopieren(){ return new Variable ;}

};

class Operator:public Ausdruck{

protected:

	Ausdruck *links;
	Ausdruck *rechts;

public:

	Operator(Ausdruck *left,Ausdruck *right):links(left),rechts(right){};


	Ausdruck *ableiten()=0;
	double auswerten(double)=0;
	char * to_chr()=0;
	Ausdruck *kopieren()=0;

	~Operator(){ delete links; delete rechts;}

};

class Add:public Operator{

public:

	Add(Ausdruck *left,Ausdruck *right):Operator(left,right){};

	Ausdruck *ableiten();
	double auswerten(double);
	char * to_chr();
	Ausdruck *kopieren();

};

class Sub:public Operator{

public:

	Sub(Ausdruck *left,Ausdruck *right):Operator(left,right){};

	Ausdruck *ableiten();
	double auswerten(double);
	char * to_chr();
	Ausdruck *kopieren();

};

class Mul:public Operator{

public:

	Mul(Ausdruck *left,Ausdruck *right):Operator(left,right){};

	Ausdruck *ableiten();
	double auswerten(double);
	char * to_chr();
	Ausdruck *kopieren();

};

class Div:public Operator{

public:

	Div(Ausdruck *left,Ausdruck *right):Operator(left,right){};

	Ausdruck *ableiten();
	double auswerten(double);
	char * to_chr();
	Ausdruck *kopieren();

};


class Pow:public Operator{

public:

	Pow(Ausdruck *left,Ausdruck *right):Operator(left,right){};

	Ausdruck *ableiten();
	double auswerten(double);
	char * to_chr();
	Ausdruck *kopieren();

};

class Funktion:public Ausdruck{

protected:

	Ausdruck *parameter;

public:

	Funktion(Ausdruck *param):parameter(param){};

	virtual Ausdruck *ableiten();
	double auswerten(double)=0;
	char * to_chr()=0;
	Ausdruck *kopieren()=0;
	virtual Ausdruck *aussen_ableitung()=0;
	// aussen_ableitung wird zur Benutzung der Kettenregel 
	// benutzt( ableitung= innere * aeusere Ableitung)

	virtual ~Funktion(){ delete parameter;}

};

class Exp:public Funktion{

public:
	Exp(Ausdruck *param):Funktion(param){}
	Ausdruck *aussen_ableitung();
	double auswerten(double);
	char * to_chr();
	Ausdruck *kopieren();
};

class Log:public Funktion{

public:
	Log(Ausdruck *param):Funktion(param){}
	Ausdruck *ableiten();

	//Aussen_ableitung wird nich gebraucht, da die Ableitung
	//von der Klasse Funktion direkt ueberladen wird
	Ausdruck *aussen_ableitung(){ return 0;}
	double auswerten(double);
	char * to_chr();
	Ausdruck *kopieren();
};

class Sqr:public Funktion{

public:
	Sqr(Ausdruck *param):Funktion(param){}
	Ausdruck *aussen_ableitung();
	double auswerten(double);
	char * to_chr();
	Ausdruck *kopieren();
};


#endif



